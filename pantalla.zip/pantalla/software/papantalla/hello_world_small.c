#include "sys/alt_stdio.h"
#include "altera_avalon_lcd_16207_regs.h"
#include "sys/alt_stdio.h"
#include "system.h"
#include "unistd.h"
#include "altera_avalon_pio_regs.h"

#define LCD_WR_COMMAND_REG 0
#define LCD_RD_STATUS_REG 1
#define LCD_WR_DATA_REG 2
#define LCD_RD_DATA_REG 3
#define LCD_0_BASE 0x5200

unsigned char boton1=0;
unsigned char boton2=0;

void lcd_init(void){
	usleep(15000);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x38);
	usleep(4100);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x38);
	usleep(100);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x38);
	usleep(5000);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x38);
	usleep(100);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x08);
	usleep(100);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x0C);
	usleep(100);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x06);
	usleep(100);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x02);
	usleep(2000);
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x01);
	usleep(2000);
}

void ESCRIBE_MENSAJE(const char *cadena, unsigned char tam){
	unsigned char i=0; for(i=0;i<tam;i++){
		IOWR(LCD_0_BASE, LCD_WR_DATA_REG, cadena[i]);
		usleep(100);
	}
}

int main (void){
	alt_putstr("Hola de nuevo\n");
	alt_putstr("Si salio jajajajaajajaja");
	lcd_init();
	IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0x02);
	usleep(2000);
	ESCRIBE_MENSAJE(" HOLA KALUN",11);
	while(1){
		boton1 = IORD_ALTERA_AVALON_PIO_DATA(0x4100) & 0x01;
		boton2 = IORD_ALTERA_AVALON_PIO_DATA(0x4100) & 0x02;
		boton2 = boton2 >> 1;
		IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0xc1);
		usleep(2000);
		if(boton1 == 1){
			ESCRIBE_MENSAJE("48,8kHz", 7);
		}
		else{ ESCRIBE_MENSAJE("97,6kHz", 7);
		}
		IOWR(LCD_0_BASE, LCD_WR_COMMAND_REG, 0xc9);
		usleep(2000);
		if(boton2 == 1){
			ESCRIBE_MENSAJE("48,8kHz", 7);
		}
		else{
			ESCRIBE_MENSAJE("195,3kHz", 8);
		}
	}
	return 0;
}
